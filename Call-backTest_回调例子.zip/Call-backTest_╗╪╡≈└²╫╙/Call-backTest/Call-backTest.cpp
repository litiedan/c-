﻿// Call-backTest.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "pch.h"
#include <iostream>
#include "CTest.h"



int main()
{
	CTest A("AAAAA");
	CTest B("BBBBB");

	CBase::whileBase();
	//CBase::Run(2);

	return 0;
}


